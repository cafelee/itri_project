from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
from utils.ride_tips import generate_ride_plan_and_tips
from utils.training_plan import generate_week_plan_json
from utils.simulation import simulate_ride
from datetime import date, datetime, timedelta
from collections import defaultdict

import os
import re
import json

# 讀取 .env 環境設定
load_dotenv('key.env')

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# 使用者模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

# 初始化資料庫
with app.app_context():
    db.create_all()

# 首頁
@app.route('/')
def index():
    #print("Session內容：", session)
    user_email = session.get('user_email') if 'user_email' in session else None
    return render_template('index.html', user_email=user_email)

@app.route('/mood')
def mood():
    return render_template('mood.html')

# 註冊
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name'].strip()
        email = request.form['email'].strip()
        password = generate_password_hash(request.form['password'])

        # 驗證 email 格式
        email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
        if not re.match(email_regex, email):
            return "Invalid email format."

        if User.query.filter_by(email=email).first():
            return "Email already exists."

        new_user = User(name=name, email=email, password=password)
        db.session.add(new_user)
        db.session.commit()

        session['user_id'] = new_user.id
        session['user_name'] = new_user.name
        session['user_email'] = new_user.email
        session['logged_in'] = True

        return redirect(url_for('index'))

    return render_template('register.html')

# 登入
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email'].strip()
        password = request.form['password']

        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_email'] = user.email
            session['logged_in'] = True
            return redirect(url_for('index'))
        else:
            return "Login failed. Invalid credentials."

    return render_template('login.html')

@app.route('/api/check_login')
def check_login():
    return {'logged_in': session.get('logged_in', False)}


@app.route('/api/plan', methods=['POST'])
def get_plan():
    data = request.get_json()
    print("Received JSON:", data)
    mode = data.get('mode', 'plan')
    if mode == 'custom':
        try:
            weight_kg = data['weight_kg']
            avg_power_w = data['avg_power_w']
            w_per_kg = data['w_per_kg']
            distance_m = data['distance_m']
            avg_grade = data['avg_grade']
            difficulty = data['difficulty']
            season = data.get('season', 'Spring')

            predicted_time = simulate_ride(
                weight_kg, avg_power_w, w_per_kg,
                distance_m, avg_grade, difficulty, season
            )
            print(f"Predicted time in seconds: {predicted_time}")
            return jsonify({
                "predicted_time": predicted_time,
                "unit": "seconds"
            })

        except Exception as e:
            print("❌ Error in simulate_ride:", e)
            return jsonify({"error": str(e)}), 400
    # default: weekly training plan
    try:
        race_date_parts = data.get('race_date')  # e.g. [2025, 7, 10]
        training_days = data.get('training_days')  # e.g. ['Tue','Wed','Thu']
        target_hours = data.get('target_hours')  # e.g. 10.0

        race_date = date(*race_date_parts)
        plan_json = generate_week_plan_json(race_date, training_days, target_hours)
        return jsonify(plan_json)
    except Exception as e:
        print("❌ Error in week plan:", e)
        return jsonify({"error": str(e)}), 400
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

def safe_float(val, default=50):
    try:
        return float(val)
    except (TypeError, ValueError):
        return default
@app.route('/segment', methods=['GET', 'POST'])
def segment():
    result = generate_ride_plan_and_tips(request)
    # metrics = result['metrics']
    tips = result['tips']
    start = request.form.get('start')
    end = request.form.get('end')
    return render_template('segment.html', start=start, end=end,
        # bmi=metrics['bmi'],
        # climb_difficulty=metrics['climb_difficulty'],
        mood_tips=tips.get('mood_tips'),
        energy_tips=tips.get('energy_tips'),
        hydration_tips=tips.get('hydration_tips'),
        time_tips=tips.get('time_tips'),
        gear_tips=tips.get('gear_tips'),
        fatigue_tips=tips.get('fatigue_tips'),
        fitness_tips=tips.get('fitness_tips'),
        weather_tips=tips.get('weather_tips'),
        bmi_tips=tips.get('bmi_tips'),
        distance_tips=tips.get('distance_tips'),
        elevation_tips=tips.get('elevation_tips')
    )


@app.route("/route")
def route_page():
    #segment_name = request.args.get("segment_name")
    distance = request.args.get("distance")
    return render_template("route.html", distance=distance)
DATA_DIR = "user_data"
os.makedirs(DATA_DIR, exist_ok=True)

@app.route('/save_ride', methods=['POST'])
def save_ride():
    content = request.json
    filename = content.get("filename") + ".json"
    data = content.get("data")

    with open(os.path.join(DATA_DIR, filename), 'w') as f:
        json.dump(data, f)

    return jsonify({"status": "success", "file": filename})

@app.route('/get_stats')
def get_stats():
    files = [f for f in os.listdir(DATA_DIR) if f.endswith('.json')]
    now = datetime.utcnow()
    
    week_stats = defaultdict(float)
    month_stats = defaultdict(float)
    year_stats = defaultdict(float)
    latest_distance = 0
    latest_speed = 0
    latest_time = None

    for f in files:
        try:
            # 解析時間
            timestamp = datetime.strptime(f.replace('.json', ''), "%Y-%m-%d-%H-%M-%S-%f")
            with open(os.path.join(DATA_DIR, f)) as file:
                data = json.load(file)
                distance = data.get('distance', 0)
                speed = data.get('avg_speed', 0)

                if not latest_time or timestamp > latest_time:
                    latest_time = timestamp
                    latest_distance = distance
                    latest_speed = speed

                # 分類進週、月、年
                week_num = (now - timestamp).days // 7
                if week_num < 4:
                    week_stats[week_num] += distance

                month_diff = (now.year - timestamp.year) * 12 + now.month - timestamp.month
                if 0 <= month_diff < 6:
                    month_stats[month_diff] += distance

                year_diff = now.year - timestamp.year
                if 0 <= year_diff < 3:
                    year_stats[year_diff] += distance
        except Exception as e:
            continue

    return jsonify({
        "week_trend": [week_stats[i] for i in range(3, -1, -1)],
        "month_trend": [month_stats[i] for i in range(5, -1, -1)],
        "year_trend": [year_stats[i] for i in range(2, -1, -1)],
        "last_distance": latest_distance,
        "avg_speed": latest_speed
    })
# 這裡是 Google Maps API 的 elevation endpoint
import requests
@app.route('/get_elevation')
def get_elevation():
    lat = request.args.get('lat')
    lng = request.args.get('lng')
    api_key = 'AIzaSyBkChog68-PM96LHebsFoRx3kybDwocur4'

    url = f'https://maps.googleapis.com/maps/api/elevation/json?locations={lat},{lng}&key={api_key}'
    res = requests.get(url)
    return jsonify(res.json())

if __name__ == '__main__':
    app.run(debug=True)
