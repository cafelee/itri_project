const app = document.getElementById('app');
const navItems = document.querySelectorAll('.nav-item');

navItems.forEach(item => {
  item.addEventListener('click', () => {
    navItems.forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const page = item.dataset.page;
    loadPage(page);
  });
});

function loadPage(page) {
  if (page === 'home') renderHome();
  else if (page === 'plans') renderPlans();
  else if (page === 'progress') renderProgress();
  else if (page === 'profile') renderProfile();
  else renderComingSoon(page);
}

// --- Home 頁 ---
function renderHome() {
  app.innerHTML = `
    <div class="logo">
      <h1>Fit</h1><span>Route AI</span>
    </div>

    <div class="welcome">
      <h2>Hello, ${user_name || 'Guest'}!</h2>
      <p>Select your cycling activity to get started</p>
    </div>

    <div class="activity-grid">
      <div class="activity-card" onclick="location.href='/mood'">
        <img src="/static/images/cycling-icon.png" alt="Cycling" style="width: 80px; height: 80px; display: block; margin: 0 auto;" />
        <p style="text-align: center; margin-top: 8px; font-size: 18px; font-weight: bold;">Cycling</p>
      </div>
      <div class="activity-card" onclick="location.href='/mood'">
        <img src="/static/images/running-icon.png" alt="Running" style="width: 80px; height: 80px; display: block; margin: 0 auto;" />
        <p style="text-align: center; margin-top: 8px; font-size: 18px; font-weight: bold;">Running</p>
      </div>
    </div>
  `;
}


// --- Plans 頁 ---
function renderPlans() {
  app.innerHTML = `
    <div class="plans-header"><h2>Training Plans</h2></div>
    <div class="tabs">
      <div class="tab active" onclick="switchTab('week')">Week</div>
      <div class="tab" onclick="switchTab('month')">Month</div>
      <div class="tab" onclick="switchTab('custom')">Custom</div>
    </div>
    <div id="plan-content"></div>
  `;
  renderWeek();
}

function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelector(`.tab[onclick*="${tab}"]`).classList.add('active');
  if (tab === 'week') renderWeek();
  else if (tab === 'month') renderMonth();
  else renderCustom();
}

// 新增 fetchAndRenderPlan，改為 renderWeek 內容
function renderWeek() {
  fetch('/api/plan', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      race_date: [2025, 7, 10],
      training_days: ['Tue','Wed','Thu','Fri','Sat','Sun'],
      target_hours: 20.0
    })
  })
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById("plan-content");

    if (data.error) {
      container.innerHTML = `<div class="error">${data.error}</div>`;
      return;
    }

    let html = `
      <div class="plan-week">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div><strong>週期階段：${data.phase}</strong></div>
          <button class="button-edit" onclick="alert('Editing Plan (Mockup)')">Edit Plan</button>
        </div>
      </div>
      <ul class="plan-list">
    `;

    for (const [day, sessions] of Object.entries(data.weekly_plan)) {
      const segments = sessions.map(seg => `${seg.name} (${seg.duration} 分)`).join(' + ');
      html += `<li><strong>${day}:</strong> ${segments}</li>`;
    }

    html += `</ul>`;
    container.innerHTML = html;
  });
}

function renderMonth() {
  document.getElementById('plan-content').innerHTML = '<p>Month plan coming soon...</p>';
}function renderCustom() {
  document.getElementById('plan-content').innerHTML = `
    <form id="custom-form">
      <input type="number" name="weight_kg" id="weight_kg" placeholder="Weight (kg)" required step="0.1">
      <input type="number" name="avg_power_w" id="avg_power_w" placeholder="Avg Power (W)" required step="1">
      <input type="number" name="distance_m" id="distance_m" placeholder="Distance (m)" required step="1">
      <input type="number" name="avg_grade" id="avg_grade" placeholder="Avg Grade (%)" required step="0.1">
      <select name="season" required>
        <option value="Spring">Spring</option>
        <option value="Summer">Summer</option>
        <option value="Fall">Fall</option>
        <option value="Winter">Winter</option>
      </select>
      <button type="submit">Simulate</button>
    </form>
    <div id="prediction-result"></div>
  `;

  const weightInput = document.getElementById('weight_kg');
  const powerInput = document.getElementById('avg_power_w');
  const distanceInput = document.getElementById('distance_m');
  const gradeInput = document.getElementById('avg_grade');

  function computeWPerKg(weight, power) {
    return (power / weight);
  }

  function computeDifficulty(distance, grade) {
    return (distance / 1000) * Math.pow(grade, 2) * 200 + (distance * grade) / 10;
  }

  function secondsToHHMMSS(seconds) {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(seconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  }

  document.getElementById('custom-form').addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const payload = { mode: "custom" };

    let weight = parseFloat(formData.get("weight_kg"));
    let power = parseFloat(formData.get("avg_power_w"));
    let distance = parseFloat(formData.get("distance_m"));
    let grade = parseFloat(formData.get("avg_grade"));

    const wPerKg = computeWPerKg(weight, power);
    const difficulty = computeDifficulty(distance, grade);

    formData.forEach((value, key) => {
      payload[key] = isNaN(value) ? value : parseFloat(value);
    });

    payload["w_per_kg"] = parseFloat(wPerKg.toFixed(2));
    payload["difficulty"] = parseFloat(difficulty.toFixed(2));

    const response = await fetch('/api/plan', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (result.error) {
      document.getElementById('prediction-result').innerHTML =
        `<div class="error">錯誤：${result.error}</div>`;
    } else {
      const hhmmss = secondsToHHMMSS(result.predicted_time);
      document.getElementById('prediction-result').innerHTML = `
        <div class="result">
          預測時間：${hhmmss}<br>
          推力比：${wPerKg.toFixed(2)} W/kg<br>
          路段難度：${difficulty.toFixed(2)}
        </div>`;
    }
  });
}


function viewDetail(title) {
  app.innerHTML = `
    <div class="plan-detail">
      <h2>${title}</h2>
      <p>Details about the plan: training instructions, goals, and expectations.</p>
      <button class="submit-btn" onclick="loadPage('plans')">Back to Plans</button>
    </div>
  `;
}

// --- Progress頁 ---
function renderProgress() {
  app.innerHTML = `
    <div class="plans-header"><h2>My Progress</h2></div>

    <div class="tabs">
      <div class="tab active">Week</div>
      <div class="tab">Month</div>
      <div class="tab">Year</div>
    </div>

    <div class="activity-grid" style="grid-template-columns: repeat(2, 1fr); margin: 20px 0;">
      <div class="plan-card" style="text-align: center;">
        <div style="font-size: 24px; color: #3b82f6;">85 km</div>
        <small>Distance</small><br><small style="color:green;">+12% from last week</small>
      </div>
      <div class="plan-card" style="text-align: center;">
        <div style="font-size: 24px; color: #3b82f6;">19.2 km/h</div>
        <small>Avg. Speed</small><br><small style="color:green;">+1.5 km/h improvement</small>
      </div>
    </div>

    <div class="plans-header" style="margin-top: 30px;"><h3>Weekly Distance</h3></div>

    <div class="plan-card" style="text-align: center;">
      <small>Last 4 Weeks</small>
      <div style="display: flex; align-items: flex-end; justify-content: space-around; margin-top: 10px; height: 80px;">
        <div style="width: 15px; height: 60%; background: linear-gradient(#93c5fd, #3b82f6); border-radius: 8px;"></div>
        <div style="width: 15px; height: 70%; background: linear-gradient(#93c5fd, #3b82f6); border-radius: 8px;"></div>
        <div style="width: 15px; height: 50%; background: linear-gradient(#93c5fd, #3b82f6); border-radius: 8px;"></div>
        <div style="width: 15px; height: 65%; background: linear-gradient(#93c5fd, #3b82f6); border-radius: 8px;"></div>
      </div>
      <small>Distance trend chart</small>
    </div>

    <div class="plans-header" style="margin-top: 30px;"><h3>Achievements <span style="float:right;color:#1f4c8a;cursor:pointer;">See All</span></h3></div>

    <div class="activity-grid" style="grid-template-columns: repeat(2, 1fr);">
      <div class="plan-card">🏆<br><strong>Century Rider</strong><br><small>Completed May 10, 2023</small></div>
      <div class="plan-card">🌅<br><strong>Early Bird</strong><br><small>Completed May 5, 2023</small></div>
      <div class="plan-card">🏔️<br><strong>Elevation Master</strong><br><small>Climb 1000m a week</small></div>
      <div class="plan-card">🔄<br><strong>Consistent Rider</strong><br><small>Ride 3x per week</small></div>
    </div>

    <div class="plans-header" style="margin-top: 30px;">
  <h3>Recent Activities <span style="float:right;color:#1f4c8a;cursor:pointer;">See All</span></h3>
</div>

<div class="activity-grid" style="grid-template-columns: 1fr;">
  <div class="plan-card" style="display:flex; align-items:center; gap:10px;">
    <div style="font-size:24px;">🗺️</div>
    <div style="flex-grow:1;">
      <strong>Morning Commute</strong><br>
      <small>18.5 km ・ May 15, 2023 ・ <span style="color:green;">+2 min faster</span></small>
    </div>
    <div style="font-weight:bold;">55 min</div>
  </div>

  <div class="plan-card" style="display:flex; align-items:center; gap:10px;">
    <div style="font-size:24px;">🗺️</div>
    <div style="flex-grow:1;">
      <strong>Weekend Trail</strong><br>
      <small>32.2 km ・ May 13, 2023 ・ <span style="color:green;">+5 min faster</span></small>
    </div>
    <div style="font-weight:bold;">1h 40m</div>
  </div>

  <div class="plan-card" style="display:flex; align-items:center; gap:10px;">
    <div style="font-size:24px;">🗺️</div>
    <div style="flex-grow:1;">
      <strong>Evening Ride</strong><br>
      <small>12.8 km ・ May 11, 2023 ・ <span style="color:red;">-3 min slower</span></small>
    </div>
    <div style="font-weight:bold;">42 min</div>
  </div>
</div>
  `;
}

// --- Profile頁 ---
function renderProfile() {

  const fitnessGoals = {
    goal: "---",
    intensity: "---",
    distance: "---",
    rides: "---"
  };

  document.getElementById("app").innerHTML = `
    <div class="plans-header"><h2>Profile</h2></div>
    <div class="plan-card" style="text-align: center; padding: 20px;" id="userDisplay">
      <div id="avatar" style="font-size: 40px;">👤</div>
      <h3 style="margin: 10px 0;">${user_name || 'Guest'}</h3>
      <p style="color: #888;">${user_email || '---'}</p>
    </div>
    
    <!-- Personal Info -->
 <div class="plans-header-with-voice" style="margin-top: 30px;">
  <h3 class="section-title">Personal Information</h3>
  <button type="button" id="voice-btn" onmousedown="startListening()" onmouseup="stopListening()">
    🎤 Voice Input
  </button>
</div>



  <div class="plan-card" style="padding: 15px;" id="personalDisplay">
    <p>Age: <strong id="ageVal">---</strong> years</p>
    <p>Gender: <strong id="genderVal">---</strong></p>
    <p>Height: <strong id="heightVal">---</strong> cm</p>
    <p>Weight: <strong id="weightVal">---</strong> kg</p>
    <p>Bike Weight: <strong id="bikeVal">---</strong> kg</p>
  </div>


    <!-- Fitness Goals -->
    <div class="plans-header" style="margin-top: 30px;">
      <h3>Fitness Goals 
        <span onclick="toggleEdit('fitnessForm')" style="float:right; cursor:pointer; color:#1f4c8a;">Edit ✏️</span>
      </h3>
    </div>
    <div class="plan-card" style="padding: 15px;" id="fitnessDisplay">
      <p>Primary Goal: <strong>${fitnessGoals.goal}</strong></p>
      <p>Weekly Distance: <strong>${fitnessGoals.distance} km</strong></p>
      <p>Weekly Rides: <strong>${fitnessGoals.rides} rides</strong></p>
    </div>
    <form id="fitnessForm" style="display:none; padding:15px;" onsubmit="event.preventDefault(); saveFitnessGoals();">
      Primary Goal: <select id="goal">
        <option value="Endurance">Endurance</option>
        <option value="Race">Race</option>
        <option value="Fat Loss">Fat Loss</option>
      </select><br><br>
      Weekly Distance (km): <input type="text" id="distance" value="${fitnessGoals.distance}"><br><br>
      Weekly Rides: <input type="text" id="rides" value="${fitnessGoals.rides}"><br><br>
      <button type="submit">Save</button>
    </form>
    <div class="plans-header" style="margin-top: 30px;">
      <h3>Account Settings</h3>
    </div>
    <div class="plan-card" style="padding: 15px;">
      <p>App Settings ➔</p>
      
    </div>
    <a href="/logout" class="setting-card">Log Out ➔</a>
    </div>
  `;

  // 函式掛到全域
  window.toggleEdit = function (id) {
    const form = document.getElementById(id);
    form.style.display = form.style.display === "none" ? "block" : "none";
  };

  // --- 語音輸入區塊 ---
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = 'zh-TW';
  recognition.continuous = false;
  recognition.interimResults = false;

  window.startListening = function () {
    recognition.start();
    document.getElementById("voice-btn").innerText = "🎤 辨識中...";
  };

  window.stopListening = function () {
    recognition.stop();
    document.getElementById("voice-btn").innerText = "🎤 Voice Input ";
  };

  recognition.onresult = function (event) {
    const transcript = event.results[0][0].transcript;
    console.log("語音結果：", transcript);

    const fuzzyWords = ["大概", "可能", "差不多", "應該", "左右", "好像"];
    const clean = transcript.replace(new RegExp(fuzzyWords.join("|"), "g"), "");

    const ageMatch = clean.match(/(\d+)\s*歲/);
    const heightMatch = clean.match(/(身高|高).*?(\d+)\s*(公分|cm)?/);
    const weightMatch = clean.match(/(體重|重).*?(\d+)\s*(公斤|kg)?/);
    const bikeWeightMatch = clean.match(/(單車|腳踏車|自行車).*?(\d+)\s*(公斤|kg)?/);
    const genderMatch = clean.match(/(男|女|男性|女性)/);

    if (ageMatch) document.getElementById("ageVal").innerText = ageMatch[1];
    if (heightMatch) document.getElementById("heightVal").innerText = heightMatch[2];
    if (weightMatch) document.getElementById("weightVal").innerText = weightMatch[2];
    if (bikeWeightMatch) document.getElementById("bikeVal").innerText = bikeWeightMatch[2];
    if (genderMatch) {
      const gender = genderMatch[1];
      document.getElementById("genderVal").innerText = gender === "男" || gender === "男性" ? "Male" : "Female";
      // 更新頭像
      const avatarIcon = gender.includes("男") ? "👨" : "👩";
      document.getElementById("avatar").innerText = avatarIcon;
    }
  };

  recognition.onerror = function (event) {
    alert("語音辨識錯誤：" + event.error);
  };
} else {
  alert("此瀏覽器不支援語音辨識（建議用 Chrome）");
}


  window.saveFitnessGoals = function () {
    const goal = document.getElementById("goal").value;
    const distance = document.getElementById("distance").value;
    const rides = document.getElementById("rides").value;

    document.getElementById("fitnessDisplay").innerHTML = `
      <p>Primary Goal: <strong>${goal}</strong></p>
      <p>Weekly Distance: <strong>${distance} km</strong></p>
      <p>Weekly Rides: <strong>${rides} rides</strong></p>
    `;

    toggleEdit("fitnessForm");
  };
}


// 預設載入 Home
renderHome();
