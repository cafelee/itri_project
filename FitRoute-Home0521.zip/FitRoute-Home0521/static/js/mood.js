function setupSlider(sliderId, emojiId, statusId, levels) {
  const slider = document.getElementById(sliderId);
  const emoji = document.getElementById(emojiId);
  const status = document.getElementById(statusId);

  slider.addEventListener('input', () => {
    const value = slider.value;
    if (value < 33) {
      emoji.textContent = levels.low.icon + ' ' + levels.label;
      status.textContent = levels.low.text;
    } else if (value < 66) {
      emoji.textContent = levels.medium.icon + ' ' + levels.label;
      status.textContent = levels.medium.text;
    } else {
      emoji.textContent = levels.high.icon + ' ' + levels.label;
      status.textContent = levels.high.text;
    }
  });

  slider.addEventListener('mouseup', () => {
    const value = slider.value;
    console.log(sliderId + ' value: ' + value); // Debug: Display slider value
    sendSliderValue(sliderId, value);
  });

  // Send initial slider values on page load
  sendSliderValue(sliderId, slider.value);
}

function sendSliderValue(sliderId, value) {
  // Use the passed value instead of reading from the DOM
  const moodValue = document.getElementById('mood-slider').value;
  const energyValue = document.getElementById('energy-slider').value;
  const hydrationValue = document.getElementById('hydration-slider').value;
  const fatigueValue = document.getElementById('fatigue-slider').value;

  console.log('Frontend slider values:');
  console.log('mood:', moodValue);
  console.log('energy:', energyValue);
  console.log('hydration:', hydrationValue);
  console.log('fatigue:', fatigueValue);

  fetch('/api/update_slider', {
    method: 'POST',
    credentials: 'include',  // 這一行才能讓 cookie 一起傳過來
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      mood: moodValue,
      energy: energyValue,
      hydration: hydrationValue,
      fatigue: fatigueValue
    })
  })
  .then(response => {
    // Store slider values in cookies
    document.cookie = `mood=${moodValue}; path=/`;
    document.cookie = `energy=${energyValue}; path=/`;
    document.cookie = `hydration=${hydrationValue}; path=/`;
    document.cookie = `fatigue=${fatigueValue}; path=/`;
  });
}

setupSlider('mood-slider', 'mood-emoji', 'mood-status', {
  label: 'Mood',
  low: { icon: '😢', text: 'Sad' },
  medium: { icon: '😐', text: 'Neutral' },
  high: { icon: '😄', text: 'Happy' }
});

setupSlider('energy-slider', 'energy-emoji', 'energy-status', {
  label: 'Energy',
  low: { icon: '🥱', text: 'Sleepy' },
  medium: { icon: '⚡', text: 'Normal' },
  high: { icon: '🔥', text: 'Energized' }
});

setupSlider('hydration-slider', 'hydration-emoji', 'hydration-status', {
  label: 'Hydration',
  low: { icon: '🥵', text: 'Thirsty' },
  medium: { icon: '💧', text: 'Okay' },
  high: { icon: '🌊', text: 'Hydrated' }
});

setupSlider('fatigue-slider', 'fatigue-emoji', 'fatigue-status', {
  label: 'Fatigue',
  low: { icon: '😎', text: 'Fresh' },
  medium: { icon: '☀️', text: 'Normal' },
  high: { icon: '😵‍💫', text: 'Exhausted' }
});

const submitBtn = document.getElementById('submit-btn');
const feelingCard = document.getElementById('feeling-card');
const resultMessage = document.getElementById('result-message');

submitBtn.addEventListener('click', (event) => {
  event.preventDefault();

  const moodSlider = document.getElementById('mood-slider');
  const energySlider = document.getElementById('energy-slider');
  const hydrationSlider = document.getElementById('hydration-slider');
  const fatigueSlider = document.getElementById('fatigue-slider');

  const moodValue = moodSlider.value;
  const energyValue = energySlider.value;
  const hydrationValue = hydrationSlider.value;
  const fatigueValue = fatigueSlider.value;

  console.log('Frontend slider values:');
  console.log('mood:', moodValue);
  console.log('energy:', energyValue);
  console.log('hydration:', energyValue);
  console.log('fatigue:', fatigueValue);

  sendSliderValue();

  fetch('/segment', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    },
    body: JSON.stringify({
      mood: moodValue,
      energy: energyValue,
      hydration: hydrationValue,
      fatigue: fatigueValue
    })
  })
  .then(response => {
    if (response.ok) {
      console.log('Slider values updated successfully!');
      window.location.href = '/segment';
    } else {
      console.error('Failed to submit form');
    }
  });
});
