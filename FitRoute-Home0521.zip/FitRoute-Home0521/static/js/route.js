let map;
let routeCoords = [];
let userCoords = [];
let userMarker = null;
let routePolyline, userPolyline;
let isTracking = false;
let watchId = null;
let startTime = null;
let sessionStartTime = null;
let elapsedSeconds = 0;
let timerInterval = null;
let isTimerRunning = false;
let totalDistance = 0;     // 單位: 公里
let averageSpeed = 0;      // 單位: 公里/小時


window.initMap = function () {
  const polylineStr = localStorage.getItem("direction_polyline");

  const decodedPath = google.maps.geometry.encoding.decodePath(polylineStr);

  const map = new google.maps.Map(document.getElementById("map"), {
    center: decodedPath[0],
    zoom: 15
  });

  const polyline = new google.maps.Polyline({
    path: decodedPath,
    map: map,
    strokeColor: '#FF0000',
    strokeOpacity: 0.9,
    strokeWeight: 7
  });

  // 自動縮放
  const bounds = new google.maps.LatLngBounds();
  decodedPath.forEach(p => bounds.extend(p));
  map.fitBounds(bounds);
};

function toggleTracking() {
  isTracking = !isTracking;
  document.getElementById('toggleBtn').textContent = isTracking ? "暫停" : "開始";
  document.getElementById('endBtn').style.display = 'inline-block';
  isTracking ? startTracking() : stopTracking();
}

function startTracking() {
  if (userCoords.length === 0) {
    sessionStartTime = new Date().toISOString();
    elapsedSeconds = 0;
    totalDistance = 0;
    document.getElementById("elapsedTime").textContent = '0';
    document.getElementById("totalDistance").textContent = '0.0';
    document.getElementById("avgSpeed").textContent = '0.0';
  }

  if (!userPolyline) {
    userPolyline = new google.maps.Polyline({
      path: [],
      map,
      strokeColor: "#0000FF",
      strokeOpacity: 1.0,
      strokeWeight: 2,
    });
  }

  if (!isTimerRunning) {
    startTime = Date.now();
    timerInterval = setInterval(() => {
      const now = Date.now();
      const currentDuration = Math.floor((now - startTime) / 1000);
      const totalElapsed = elapsedSeconds + currentDuration;

      document.getElementById("elapsedTime").textContent = totalElapsed;
      const avg = totalDistance / totalElapsed;
      document.getElementById("avgSpeed").textContent = (avg * 3.6).toFixed(1);
    }, 1000);
    isTimerRunning = true;
  }

  watchId = navigator.geolocation.watchPosition((pos) => {
    const { latitude, longitude } = pos.coords;
    const position = new google.maps.LatLng(latitude, longitude);
    userCoords.push(position);
    userPolyline.setPath(userCoords);

    if (!userMarker) {
      userMarker = new google.maps.Marker({
        position,
        map,
        title: "你的位置",
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: '#4285F4',
          fillOpacity: 1,
          strokeWeight: 2,
          strokeColor: 'white',
        }
      });
    } else {
      userMarker.setPosition(position);
    }

    if (userCoords.length >= 2) {
      const prev = userCoords[userCoords.length - 2];
      const dist = google.maps.geometry.spherical.computeDistanceBetween(prev, position);
      if (dist > 1) {
        totalDistance += dist;
        document.getElementById("totalDistance").textContent = totalDistance.toFixed(1);
      }
    }

    const onRoute = routeCoords.some(p => {
      const routePoint = new google.maps.LatLng(p.lat, p.lng);
      return google.maps.geometry.spherical.computeDistanceBetween(position, routePoint) < 10;
    });

    updateStatus(onRoute ? "✅ 在路線上" : "❌ 偏離路線");
  }, (err) => {
    updateStatus("❌ 定位錯誤：" + err.message);
  }, {
    enableHighAccuracy: true,
    maximumAge: 1000,
    timeout: 5000
  });
}

function stopTracking() {
  if (watchId) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
  if (timerInterval) {
    const pausedAt = Date.now();
    const duration = Math.floor((pausedAt - startTime) / 1000);
    elapsedSeconds += duration;

    clearInterval(timerInterval);
    timerInterval = null;
    isTimerRunning = false;
  }
}

function endSession() {
  const endTime = new Date();
  const filename = sessionStartTime.replace(/[:.]/g, '-').replace('T', '-').replace('Z', '');

  const durationMs = endTime - new Date(sessionStartTime);
  const durationSec = Math.floor(durationMs / 1000);
  const hours = Math.floor(durationSec / 3600);
  const minutes = Math.floor((durationSec % 3600) / 60);
  const seconds = durationSec % 60;

  const durationStr = `${hours}h${minutes}m${seconds}s`;

  const data = {
    start_time: sessionStartTime,
    duration: durationStr,
    distance: totalDistance,        // 公里
    average_speed: averageSpeed     // 公里/小時
  };

  fetch('/save_ride', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ filename, data })
  }).then(res => {
    console.log('已儲存:', res);
    location.href = '/'; // 儲存完成後回首頁
  });
}


function updateStatus(text) {
  const statusEl = document.getElementById("status");
  if (statusEl) statusEl.textContent = text;
}