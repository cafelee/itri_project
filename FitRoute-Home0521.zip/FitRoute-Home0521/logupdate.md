0512-S
更新:
將註冊登入系統整合進0428原檔
login/ log out 按鈕已加入
底部navbar自適應+固定不動
各頁面空間保留滑到最下方空間(不會被遮擋)

問題:
http://127.0.0.1:5000進入後無法正常跳轉-->泰宇已解決，因跳轉CSS連結未寫完整。

0513-宇
更新 : 
註冊系統整合, Profile加入語音辨識以及填寫表單
mood.html跳轉不順利, 需再研究如何調整。

0514-宇
release note : 
-mood.html跳轉報錯解決。
-新增segment初版介面。

0515-S
更新:
新增mood.html頁面路段起點與終點按鈕
Back to home按鈕尺寸修改
segment.html頁面新增三個按鈕:[Reset Filters],[Return to Home],[Start Workout!]

0517-S
更新:
調整LOGO樣式大小以及位置(下一版會貼齊頂部)
HOME頁按鈕調整為兩個，新增ICON
PROFILE頁語音輸入按鈕樣式美化

0519-宇
release note:
項目plans隱藏, 會員登入才會顯示並可使用
Fitness Goals移除Intensity欄位
Fitness Goals新增Primary Goal下拉式選單(Endurance/Race/Fat Loss)
新增route.js及route.html(計算導航位移時間), 尚未執行, 待map完成會再測試

0520-宇,任,非
release note:
地圖顯示完成, 且也配合表單送出建議配速資料等等。
plans頁面Custom初版設計:輸入體重, FTP, 路段距離等等, 依照train的模型判斷難度, 預計完成時間, 速率等等。

0521-Jacky
release note:
新增位移導航頁面以及儲存使用者運動紀錄。
