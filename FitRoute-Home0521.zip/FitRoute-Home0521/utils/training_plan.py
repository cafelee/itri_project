import random
from datetime import date
# util/training_plan.py


# 一、訓練模板（分鐘範圍）
training_templates = {
    'a': {'name': 'Recovery Ride',    'duration_range': (30, 45)},
    'b': {'name': 'Endurance',        'duration_range': (120, 240)},
    'c': {'name': 'Tempo',            'duration_range': (90, 120)},
    'd': {'name': 'Threshold',        'duration_range': (60, 90)},
    'e': {'name': 'VO2 Max',          'duration_range': (45, 60)},
    'f': {'name': 'Anaerobic/Sprint', 'duration_range': (45, 60)},
    'g': {'name': 'Rest',             'duration_range': (0, 0)},
}

def sample_duration(code: str) -> int:
    lo, hi = training_templates[code]['duration_range']
    m = random.uniform(lo, hi)
    if code == 'b':
        return int(round(m / 30) * 30)
    else:
        return int(round(m / 10) * 10)

# 二、週期階段判斷
def determine_training_phase(current_date: date, race_date: date | None) -> str:
    if not race_date:
        return 'no_race'
    weeks_left = (race_date - current_date).days // 7
    if weeks_left > 12:
        return 'base_early'
    elif 9 <= weeks_left <= 12:
        return 'base_late'
    elif 6 <= weeks_left <= 8:
        return 'build_early'
    elif 3 <= weeks_left <= 5:
        return 'build_late'
    elif weeks_left <= 2:
        return 'peak'
    else:
        return 'no_race'

# 三、各階段 min/max 限制
def get_blocks_limits(phase: str) -> dict:
    if phase in ('base_early', 'base_late'):
        return {'a':{'min':0,'max':1}, 'b':{'min':2,'max':4},
                'c':{'min':1,'max':2}, 'd':{'min':0,'max':1},
                'e':{'min':0,'max':0}, 'f':{'min':0,'max':0}}
    elif phase in ('build_early','build_late'):
        return {'a':{'min':0,'max':1}, 'b':{'min':1,'max':3},
                'c':{'min':1,'max':2}, 'd':{'min':1,'max':2},
                'e':{'min':0,'max':1}, 'f':{'min':0,'max':1}}
    elif phase == 'peak':
        return {'a':{'min':0,'max':1}, 'b':{'min':1,'max':2},
                'c':{'min':0,'max':2}, 'd':{'min':1,'max':2},
                'e':{'min':1,'max':2}, 'f':{'min':0,'max':1}}
    else:
        return {'a':{'min':0,'max':2}, 'b':{'min':1,'max':3},
                'c':{'min':0,'max':2}, 'd':{'min':0,'max':1},
                'e':{'min':0,'max':0}, 'f':{'min':0,'max':0}}

# 四、產生週計劃並逐步放寬限制
def generate_plan_with_relax(training_days: list[str],
                             blocks_limits: dict,
                             target_hours: float,
                             tolerance: float = 30,
                             max_attempts: int = 1000) -> dict | None:

    target_min = int(target_hours * 60)
    if not (300 <= target_min <= 1200):
        raise ValueError("每週訓練時數必須介於 5–20 小時之間")

    week_days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
    non_train = [d for d in week_days if d not in training_days]
    intensity = {'c','d','e','f'}

    # 硬性條件
    def hard_total_range(plan):
        total = sum(sum(seg[1] for seg in plan[d]) for d in training_days)
        return 300 <= total <= 1200

    def hard_total_within(plan):
        total = sum(sum(seg[1] for seg in plan[d]) for d in training_days)
        return abs(total - target_min) <= tolerance

    hard_constraints = [
        ('時數硬性 300–1200 分鐘', hard_total_range),
        ('時數必須在目標 ± 容差',   hard_total_within),
    ]

    # 可放寬限制
    def max_intensity(plan):
        return sum(1 for d in training_days if plan[d][0][0] in intensity) <= 3

    def max_recovery(plan):
        return sum(1 for d in training_days if plan[d][0][0]=='a') <= 1

    def no_four_consec(plan):
        consec = 0
        for d in week_days:
            code = plan[d][0][0]
            if code in ('g','a'):
                consec = 0
            else:
                consec += 1
                if consec > 3:
                    return False
        return True

    relaxable = [
        ('最多三天強度日',   max_intensity),
        ('最多一次Recovery',max_recovery),
        ('不超過3天連續',    no_four_consec),
    ]

    for r in range(len(relaxable)+1):
        active = hard_constraints + relaxable[:len(relaxable)-r]
        def valid(plan):
            return all(fn(plan) for _, fn in active)

        for _ in range(max_attempts):
            # 1. 初始化 counts
            counts = {k: blocks_limits[k].get('min',0) for k in blocks_limits}
            slots = len(training_days) - sum(counts.values())
            if slots < 0:
                break

            # 2. 填 slots
            avail = [k for k in blocks_limits if counts[k] < blocks_limits[k]['max']]
            for _ in range(slots):
                if not avail: break
                k = random.choice(avail)
                counts[k] += 1
                if counts[k] >= blocks_limits[k]['max']:
                    avail.remove(k)

            # 3. 排列 codes
            mods = []
            for code, cnt in counts.items():
                mods += [code]*cnt
            random.shuffle(mods)

            # 4. 建立 plan，強度後「隨機」附帶 b (50% 機率)
            plan = {}
            for day, code in zip(training_days, mods):
                segs = [(code, sample_duration(code))]
                if code in intensity and random.random() < 0.5:
                    segs.append(('b', sample_duration('b')))
                plan[day] = segs
            for day in non_train:
                plan[day] = [('g', 0)]

            if valid(plan):
                if r>0:
                    print(f"⚠️ 已放寬 {r} 項限制")
                return plan

    return None

# 五、示範使用
if __name__ == "__main__":
    random.seed(42)

    today = date.today()
    race_date = date(2025, 7, 10)
    training_days = ['Tue','Wed','Thu','Fri','Sat','Sun']
    target_hours = 20.0

    phase = determine_training_phase(today, race_date)
    print(f"週期階段：{phase}")

    limits = get_blocks_limits(phase)
    plan = generate_plan_with_relax(training_days, limits, target_hours)

    if plan:
        print("本週課表（分鐘）：")
        for d in ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']:
            segs = plan[d]
            parts = " + ".join(f"{training_templates[code]['name']}({dur})" for code,dur in segs)
            print(f"{d}: {parts}")
    else:
        print("❌ 無法產生符合所有硬性條件的課表")

# ...（你原本的所有程式碼都保留不動）

def generate_week_plan_json(race_date: date,
                            training_days: list[str],
                            target_hours: float) -> dict:
    today = date.today()
    phase = determine_training_phase(today, race_date)
    limits = get_blocks_limits(phase)
    plan = generate_plan_with_relax(training_days, limits, target_hours)
    print("plan:", plan)

    if not plan:
        return {"error": "❌ 無法產生符合所有硬性條件的課表"}

    # 組成 JSON 結構
    week_plan = {}
    for d in plan:  # 改這裡
        segs = plan[d]
        week_plan[d] = [
            {
                "code": code,
                "name": training_templates[code]['name'],
                "duration": duration
            }
            for code, duration in segs
        ]


    return {
        "phase": phase,
        "weekly_plan": week_plan
    }
