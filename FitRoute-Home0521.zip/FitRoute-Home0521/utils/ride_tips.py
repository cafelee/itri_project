import random
from flask import request
from typing import Dict, List

def pick(tip_list: List[str]) -> str:
    """Randomly selects one tip from a list"""
    return random.choice(tip_list)

# Enhanced tips texts dictionary with all new categories
texts = {
    # Mood Tips (4 tiers)
    "mood_tips": lambda mood: pick([
        "🆘 情緒能量極低，建議改做輕度恢復騎或休息日",
        "🌧️ 心理狀態需優先照顧，騎車時請專注呼吸節奏",
        "🤗 給自己一個溫柔的目標：騎到第一個便利商店就好",
        "🧠 情緒低落時，Zone 1 強度最能穩定心神",
        "🫂 戴上降噪耳機，用最慢速踩踏療癒自己",
        "☕ 先喝杯熱飲再出發，從家門口開始就好",
        "📞 找個騎伴同行，群騎能有效改善情緒"
    ]) if mood < 15 else pick([
        "😕 心情低落，建議以放鬆騎乘為主",
        "🌥️ 今天可能情緒不高，來趟輕鬆療癒騎吧",
        "🧘 尋找風景或音樂，幫助提升騎乘心情",
        "🎧 播個音樂，輕鬆騎，心情會慢慢好起來",
        "🚲 騎車是治癒良藥，別太在意配速",
        "🌿 選擇河濱或公園路線，綠色環境有助舒壓",
        "⏳ 設定30分鐘短程目標，完成後獎勵自己"
    ]) if mood < 40 else pick([
        "😐 心情普通，選擇風景佳路線有助提振精神",
        "🌄 規劃中途咖啡廳停留點創造小期待",
        "🔄 試試新路線，新鮮感能轉換心情",
        "👟 穿戴最舒適的裝備，減少心理負擔",
        "📸 邊騎邊拍照，用探索者心態享受過程",
        "🧩 分段設定小目標（如每5km換姿勢）",
        "🤸 加入短暫的伸展停頓，活化身心連結"
    ]) if mood < 80 else pick([
        "😊 心情極佳，適合嘗試挑戰路線！",
        "🚴‍♂️ 高情緒能量正是突破PB的好時機",
        "🏔️ 規劃陡坡路段，把快樂轉換成動能",
        "🌟 試著在Strava上創建新賽段",
        "💯 完美狀態！可增加20%訓練量",
        "👥 召集騎友共享這份能量",
        "🎯 大膽設定比平常多15km的目標"
    ]),

    # Energy Tips (3 tiers)
    "energy_tips": lambda energy: pick([
        "⚡ 能量危機！請先進食300大卡再評估",
        "🍌 立即補充快碳（香蕉/能量膠）",
        "🛑 不建議騎乘，優先補充電解質與休息",
        "💤 上次訓練未完全恢復，強制運動可能受傷",
        "🩸 血糖過低徵兆，建議飲用含糖飲料",
        "🏥 如伴隨頭暈請就醫檢查",
        "🍯 蜂蜜水+鹽片緊急處理後再出發"
    ]) if energy < 20 else pick([
        "🔋 能量過低，出發前吃根香蕉或能量棒",
        "⏳ 延後30分鐘出發，先補充消化",
        "🚫 避免超過Zone 2強度",
        "🍞 選擇低纖維碳水減少腸胃負擔",
        "🥛 乳清蛋白飲料可快速提供能量",
        "🧂 搭配少量鹽分提升吸收速度",
        "🍇 葡萄糖錠是緊急選擇"
    ]) if energy < 40 else pick([
        "💥 能量爆棚！適合高強度間歇訓練",
        "🏆 挑戰爬坡賽段或衝刺練習",
        "⏱️ 嘗試Tabata或30秒全力衝刺",
        "🦵 增加踏頻訓練比重",
        "📊 執行FTP測試的最佳狀態",
        "🔥 能量充足，可增加15%訓練量",
        "🚵 混合地形訓練發揮最大潛力"
    ]),

    # Hydration Tips (2 tiers)
    "hydration_tips": lambda h: pick([
        "💧 水分不足，建議出發前喝 300~500ml",
        "🥤 水分低，運動飲料能提升吸收效率",
        "🚰 多喝水有助體溫調節與續航",
        "☀️ 高溫天氣更要定時補水！",
        "💦 保持水分才能穩定輸出",
        "🩺 脫水徵兆：口乾、頭痛、尿液深黃",
        "🧊 水中加冰塊可降低核心溫度"
    ]) if h < 30 else pick([
        "👍 水分充足，持續補水即可",
        "😌 水分狀態良好，注意氣候變化即可",
        "💧 記得 15~20 分鐘小口喝水一次",
        "🌡️ 每小時補充400-600ml為理想值",
        "🍋 加片檸檬增加飲水意願",
        "🔄 交替喝清水與電解質飲料",
        "⏲️ 設定手錶每15分鐘提醒喝水"
    ]),

    # Gear Tips
    "gear_tips": lambda distance, weather: pick([
        "🛠️ 長距離必備：備用內胎/挖胎棒/CO2氣瓶",
        "🧴 防摩擦膏塗抹易磨損部位",
        "🎒 建議使用雙水壺架或水袋背包",
        "📱 攜帶行動電源確保導航不中斷",
        "🍬 能量膠每45分鐘補充一次",
        "🧂 電解質錠加入水中預防抽筋",
        "👓 偏光鏡片減少長時間眩光傷害"
    ]) if distance > 80 else (pick([
        "🌧️ 雨天裝備：全覆式擋泥板必裝",
        "🧤 防滑手套保持煞車控制力",
        "👟 防水鞋套或換穿登山車鞋",
        "🛑 碟煞優先，V煞需提前檢查皮",
        "🚨 增加尾燈亮度（雨霧中可見度降50%）",
        "🧥 防水風衣要測試腋下透氣度",
        "🕶️ 使用透明鏡片替代墨鏡"
    ]) if "rain" in weather.lower() else ""),

    # Fatigue Tips (3 tiers)
    "fatigue_tips": lambda fatigue: pick([
        "🛌 疲勞指數爆表！建議完全休息日",
        "💤 深度睡眠不足，騎乘風險增加",
        "🧘 改做瑜伽或游泳等交叉訓練",
        "🩺 連續高疲勞可能導致過度訓練症候群",
        "🍌 補充鎂離子幫助肌肉放鬆",
        "🧊 運動後冰浴加速恢復",
        "📉 強制運動可能造成運動表現下降30%"
    ]) if fatigue >= 85 else pick([
        "⚠️ 疲勞偏高，應避免劇烈運動",
        "🚲 改為輕鬆騎，保持<60%最大心率",
        "🧂 電解質失衡可能是疲勞原因",
        "⏱️ 縮短原計劃訓練時間50%",
        "🍏 補充含鉀食物（香蕉/菠菜）",
        "💤 今晚保證7小時以上睡眠",
        "🧊 運動後冷熱交替淋浴"
    ]) if fatigue >= 70 else pick([
        "✅ 身體狀況佳，適合高強度訓練",
        "🏋️ 可嘗試突破現有FTP數值",
        "🔥 挑戰間歇訓練：8組1分鐘全力衝刺",
        "🦵 增加爬坡訓練比重",
        "📊 執行FTP測試的最佳狀態",
        "💨 逆風路段保持高踏頻",
        "⛰️ 規劃高強度爬坡路線"
    ]),

    # Fitness Goal Tips
    "fitness_tips": lambda goal: pick([
        "耐力訓練，重點為穩定配速與補給節奏",
        "賽事導向，建議模擬比賽節奏與地形",
        "減脂訓練，保持Zone 2強度最有效",
        "恢復騎：維持60-65%最大心率",
        "技術訓練：專注過彎與變速技巧",
        "衝刺訓練：8-12組30秒全力輸出",
        "爬坡特訓：選擇坡度5-8%的路段"
    ]) if "endurance" in goal else pick([
        "賽前準備：模擬比賽日補給策略",
        "競速訓練：乳酸閾值間歇4×8分鐘",
        "衝刺技巧：練習搖車與站立騎乘",
        "戰術訓練：跟車輪車與突圍練習",
        "終點衝刺：200m全力衝刺訓練",
        "器材優化：調整騎姿減少風阻",
        "心理建設：視覺化比賽過程"
    ]) if "race" in goal else pick([
        "脂肪代謝：保持心率Zone 2持續45+分鐘",
        "空腹訓練：晨騎前少量補充蛋白質",
        "補給控制：每小時限200大卡攝入",
        "延長運動：低強度長時間最有效",
        "核心強化：每20分鐘加入1分鐘平板",
        "HIIT訓練：1分鐘衝刺+2分鐘恢復",
        "飲食配合：運動後30分鐘內避免碳水"
    ]) if "fat" in goal else "",

    # Weather Tips
    "weather_tips": lambda weather: (pick([
        "風勢強，建議逆風段保守應對",
        "側風危險，保持雙手握把手",
        "強風警告！降低車架高度騎乘",
        "團體騎乘可輪車減少風阻",
        "逆風配速降低10-15%保體力",
        "注意突風可能影響平衡",
        "穿戴緊身風衣減少阻力"
    ]) if "wind" in weather.lower() else pick([
        "高溫警報！每15分鐘補水一次",
        "防曬必備：SPF50+與太陽鏡",
        "選擇透氣排汗的淺色車衣",
        "避開10:00-14:00日照高峰",
        "頭部降溫：溼毛巾或水淋",
        "注意熱衰竭徵兆：頭暈/噁心",
        "鹽錠補充預防熱痙攣"
    ]) if "hot" in weather.lower() or "sun" in weather.lower() else pick([
        "低溫注意：分層穿衣法",
        "關節保暖：膝蓋與腳踝",
        "熱身延長至20分鐘以上",
        "防風外套必備",
        "避免汗水積聚導致失溫",
        "手套+鞋套防凍傷",
        "呼吸技巧：鼻吸嘴吐"
    ]) if "cold" in weather.lower() else pick([
        "溼滑路面煞車距離加倍",
        "裝擋泥板避免濺水",
        "胎壓降低5-10psi增加抓地",
        "避開路面標線與金屬蓋",
        "雨後特別注意碎石與樹枝",
        "準備防水電子設備袋",
        "騎後立即清潔鏈條"
    ]) if "rain" in weather.lower() else ""),

    # BMI Tips
    "bmi_tips": lambda bmi: pick([
        "BMI偏高，建議Zone 2耐力訓練",
        "選擇平把車型減輕腰部壓力",
        "坐墊寬度應足夠支撐骨盆",
        "避免陡坡減少膝蓋負擔",
        "運動前後充分動態伸展",
        "交叉訓練搭配游泳更安全",
        "注意飲食與運動的熱量平衡"
    ]) if bmi >= 30 else pick([
        "BMI過低，需加強營養攝取",
        "運動後30分鐘內補充蛋白質",
        "避免空腹訓練導致肌肉流失",
        "適度重量訓練增加肌肉量",
        "監測晨起靜止心率防過度",
        "增加健康脂肪攝取",
        "考慮運動營養師諮詢"
    ]) if bmi < 18.5 else "",

    # Distance Tips
    "distance_tips": lambda distance: pick([
        "世紀騎行！規劃3-4個補給站",
        "準備兩套以上補給品",
        "每小時檢查一次身體狀況",
        "配速比平常慢10-15%",
        "攜帶現金以備緊急補給",
        "安排中途車輛支援點",
        "分段心理目標設定法"
    ]) if distance > 100 else pick([
        "中等距離，出發前充份補給",
        "攜帶至少兩瓶水或運動飲料",
        "每45分鐘補充能量膠",
        "注意坐姿變換預防麻木",
        "規劃1-2個短暫休息點",
        "避免前半段過度興奮衝刺",
        "終點保留10%體力"
    ]) if distance > 50 else pick([
        "短距離可安排間歇訓練",
        "適合技術練習：過彎/變速",
        "高強度訓練前充分熱身",
        "嘗試新的騎行姿勢",
        "衝刺訓練後充分冷卻",
        "短程探索新路線的好機會",
        "專注踏頻控制練習"
    ]) if distance < 30 else "",

    # Elevation Tips
    "elevation_tips": lambda gradient: pick([
        "高強度爬坡，齒比預先調整",
        "保持踏頻70-80rpm最有效率",
        "爬坡前減少胃部食物重量",
        "採用之字形騎法減緩坡度",
        "心理技巧：分段視覺化",
        "注意上半身放鬆避免浪費體力",
        "下坡前檢查煞車系統"
    ]) if gradient > 3.5 else pick([
        "連續爬坡，配速比平地慢20%",
        "預先研究坡段長度與坡度",
        "爬坡呼吸：深腹式呼吸",
        "避免站立騎乘消耗過多體力",
        "頂峰前保留10%體力",
        "利用下坡充分恢復",
        "補給時機：爬坡前後"
    ]) if gradient > 1.5 else "",

    # Functional Tips (unchanged)
    "calories_tip": lambda c: f"🔥 預估熱量消耗 {c:.0f} kcal，建議補給 {int(c // 300)} 次。🍌🍞",
    "water_tip": lambda w: f"💧 建議補水總量約 {int(w)} ml，運動中加入電解質會更有效",
    "time_tip": lambda t: f"⌛ 預計完成時間約 {int(t)} 分鐘，請安排補給節奏與休息點",
    "speed_tip": lambda s: pick([
        f"🚴‍♂️ 建議配速為 {s:.1f} km/h，維持穩定輸出",
        f"⏱️ 配速建議 {s:.1f} km/h，適合持久訓練",
        f"🧭 避免忽快忽慢，建議維持 {s:.1f} km/h 左右",
        f"📈 根據狀態可±2km/h動態調整",
        f"🔄 每20分鐘微調配速避免疲勞累積"
    ])
}


def safe_float(val, default=50.0):
    try:
        return float(val)
    except (TypeError, ValueError):
        return default

def generate_ride_plan_and_tips(req) -> Dict:
    data = req.form or req.args or {}

    # 優先順序：form > cookie > default
    mood = safe_float(data.get('mood', req.cookies.get('mood')), 50)
    energy = safe_float(data.get('energy', req.cookies.get('energy')), 50)
    hydration = safe_float(data.get('hydration', req.cookies.get('hydration')), 50)
    fatigue = safe_float(data.get('fatigue', req.cookies.get('fatigue')), 50)
    height_cm = safe_float(data.get('height', req.cookies.get('height')), 170)
    weight_kg = safe_float(data.get('weight', req.cookies.get('weight')), 70)
    goal = data.get('goal', req.cookies.get('goal', 'Endurance')).lower()

    distance_km = safe_float(data.get('distance_km'), 50)
    elevation = safe_float(data.get('elevation_gain'), 500)
    weather = data.get('weather', 'Sunny')
    # Debug print 所有值
    print("🚴 Input Parameters:")
    print(f"  Mood: {mood}")
    print(f"  Energy: {energy}")
    print(f"  Hydration: {hydration}")
    print(f"  Fatigue: {fatigue}")
    print(f"  Height (cm): {height_cm}")
    print(f"  Weight (kg): {weight_kg}")
    print(f"  Goal: {goal}")
    print(f"  Distance (km): {distance_km}")
    print(f"  Elevation gain (m): {elevation}")
    print(f"  Weather: {weather}")
    # 計算衍生參數
    climb_difficulty = elevation / distance_km if distance_km else 0
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2) if height_m else 0

 
    tips = {
        "mood_tips": [texts["mood_tips"](mood)],
        "energy_tips": [texts["energy_tips"](energy)] if energy else [],
        "hydration_tips": [texts["hydration_tips"](hydration)] if hydration else [],
        "gear_tips": [texts["gear_tips"](distance_km, weather)] if distance_km and weather else [],
        "fatigue_tips": [texts["fatigue_tips"](fatigue)] if fatigue else [],
        "fitness_tips": [texts["fitness_tips"](goal)] if goal else [],
        "weather_tips": [texts["weather_tips"](weather)] if weather else [],
        "bmi_tips": [texts["bmi_tips"](bmi)] if bmi else [],
        "distance_tips": [texts["distance_tips"](distance_km)] if distance_km else [],
        "elevation_tips": [texts["elevation_tips"](climb_difficulty)] if climb_difficulty else [],
    }

    tips = {k: v for k, v in tips.items() if v and v[0]}

    return {
        "metrics": {
            "bmi": round(bmi, 1),
            "climb_difficulty": round(climb_difficulty, 2)
        },
        "tips": tips
    }
